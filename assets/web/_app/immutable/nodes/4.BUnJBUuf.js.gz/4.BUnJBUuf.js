import"../chunks/DsnmJJEf.js";import"../chunks/69_IOA4Y.js";import{S as o}from"../chunks/CbxZuxnD.js";function m(r){o(r,{})}export{m as component};
