import{a8 as o,a9 as s}from"./BOqQhZBJ.js";function n(t=Symbol()){return{get:()=>s(t),set:e=>o(t,e)}}const{get:r,set:C}=n();export{n as c,r as g,C as s};
