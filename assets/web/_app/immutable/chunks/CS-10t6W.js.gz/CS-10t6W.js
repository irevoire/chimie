const r=e=>e.normalize("NFD").replaceAll(/[\u0300-\u036F]/g,""),n=e=>r(e.toLocaleLowerCase());export{n};
