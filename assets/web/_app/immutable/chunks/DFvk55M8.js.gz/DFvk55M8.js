const i=t=>{t.focus()};export{i};
