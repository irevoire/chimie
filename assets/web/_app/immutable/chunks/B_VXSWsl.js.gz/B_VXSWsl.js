import{l as t}from"./DeYUhNiz.js";function i(r){return r instanceof t}export{i};
