import{j as s,h as a,g as o}from"./BOqQhZBJ.js";let t=a(void 0);const l=()=>o(t),g=e=>{s(t,e,!0)};export{l as g,g as s};
