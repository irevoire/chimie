const s={};export{s as default};
