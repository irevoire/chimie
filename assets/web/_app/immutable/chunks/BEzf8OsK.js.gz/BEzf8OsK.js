import"./DsnmJJEf.js";import{f as i}from"./BOqQhZBJ.js";import{c as m,s as n,a as p}from"./CnteGC4G.js";function c(r,o){var a=m(),t=i(a);n(t,()=>o.children),p(r,a)}export{c as L};
