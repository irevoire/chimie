import{U as r}from"./BOqQhZBJ.js";const a=r({isDragging:!1,files:[]});export{a as d};
