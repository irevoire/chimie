import{b as s}from"./BeWG-__C.js";function o(a,r){return s(a,r)}export{o as i};
